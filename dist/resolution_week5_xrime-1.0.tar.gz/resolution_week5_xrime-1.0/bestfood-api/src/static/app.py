from browser import document, html, aio, window
import json

STORE = "api_key"

def show(msg, good= False):
    box = document["status"]
    box.text = msg
    box.style.padding = "10px"
    box.style.borderRadius = "6px"
    box.style.marginTop = "10px"
    box.style.background = "#d4edda" if good else "#f8d7da"
    box.style.color = "#155724" if good else "#721c24"
    box.style.border = "1px solid #c3e6cb" if good else "1px solid #f5c6cb"

def key():
    return document ["api-key"].value.strip()
def save_key(k):
    document["api-key"].value = k
    try:
        window.localStorage.setItem(STORE, k)
    except Exception:
        pass

def load_key():
    try:
        v = window.localStorage.getItem(STORE)
        if v is not None:
            document["api-key"].value = v
    except Exception:
        pass

def render(spots):
    box = document["spots-list"]
    box.clear()

    if not spots:
        box <= html.P("No spots yet. Add one above!", Class="sub")
        return
    
    for s in spots:
        item = html.DIV(Class="card")
        item<= html.B(s["name"])
        item<= html.SPAN(f'- {s["location"]} - Rating: {s["rating"]}')
        item<=html.BR()
        item<= html.SPAN(f'ID: {s["id"]}', Class="sub")
        item<= html.BR()

        btn= html.BUTTON("Delete", Class="clearbtn")

        async def do_del(ev, spot_id=s["id"]):
            await delete_spot(spot_id)
        
        btn.bind("click", lambda ev, f=do_del: aio.run(f(ev)))
        item<= btn
        box<=item

async def register(ev):
    name =document["register-name"].value.strip()
    if not name:
        show("Type your name first.")
        return
    r = await aio.post(
        "/register",
        headers={"Content-Type": "application/json"},
        data=json.dumps({"name": name}),
    )

    if r.status != 200:
        show(f"Register failed({r.status})")
        return
    
    data = json.loads(r.data)
    save_key(data["api_key"])
    show("Registered! Api key saved.", good= True)
    await refresh(None)


async def refresh(ev):
    if not key():
        show("Enter your api key")
        return

    r = await aio.get("/food-spots", headers={"x-api-key": key()})
    if r.status != 200:
        show(f"Load failed ({r.status}). Check Api key")
        return
    try:
        spots = json.loads(r.data)
    except:
        show("Failed to parse spots data.")
        return
    render(spots)


async def add_spot(ev):
    if not key():
        show("Enter your api key")
        return
    name = document["spot-name"].value.strip()
    location = document["spot-location"].value.strip()
    rating_text = document["spot-rating"].value.strip()

    if not (name and location and rating_text):
        show("Fill name, location, and rating.")
        return
    try:
        rating = float(rating_text)
    except:
        show("Rating must be a number (example: 4.0)")
        return

    r = await aio.post(
        "/food-spots",
        headers={"x-api-key": key(), "Content-Type": "application/json"},
        data=json.dumps({"name": name, "location": location, "rating": rating}),
    )

    if r.status != 200:
        show(f"Add failed ({r.status})")
        return
    show("Added.", good=True)
    await refresh(None)

async def delete_spot(spot_id):
    r = await aio.ajax("DELETE", f"/food-spots/{spot_id}", headers={"x-api-key": key()})
    if r.status != 200:
        show(f"Delete failed ({r.status})")
        return

    show("Deleted.", good=True)
    await refresh(None)


def save_btn(ev):
    try:
        k = key()
    except Exception as e:
        show(f"Save failed: {e}")
        return
    if not k:
        show("No key to save.")
        return
    try:
        window.localStorage.setItem(STORE, k)
        show("API key saved.", good=True)
    except Exception as e:
        show(f"Save failed: {e}")


def clear_btn(ev):
    try:
        window.localStorage.removeItem(STORE)
    except Exception as e:
        show(f"Clear failed: {e}")
        return
    document["api-key"].value = ""
    show("API key cleared.", good=True)


document["register-btn"].bind("click", lambda ev: aio.run(register(ev)))
document["refresh-btn"].bind("click", lambda ev: aio.run(refresh(ev)))
document["add-spot-btn"].bind("click", lambda ev: aio.run(add_spot(ev)))

document["save-key"].bind("click", save_btn)
document["clearbtn"].bind("click", clear_btn)

load_key()
if key():
    aio.run(refresh(None))
else:
    show("Register or paste your API key to begin.", good=True)
    



